#define TIME_ARRAY_SIZE  100
#define POS_ARRAY_SIZE   512

int get_timeset(float [], float [], float []);

