#define NTAPS 13

int get_room(int [], float [], float [], double);

