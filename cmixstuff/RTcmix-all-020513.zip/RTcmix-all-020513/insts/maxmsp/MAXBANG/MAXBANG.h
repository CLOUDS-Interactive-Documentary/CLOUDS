class MAXBANG : public Instrument {

public:
	MAXBANG();
	virtual ~MAXBANG();
	virtual int init(double*, int);
	virtual int run();
	};
