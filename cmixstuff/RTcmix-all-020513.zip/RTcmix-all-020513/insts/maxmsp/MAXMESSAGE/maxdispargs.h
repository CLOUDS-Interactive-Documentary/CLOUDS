#ifndef _MAXDISPARGS_H
#define _MAXDISPARGS_H 1

#define  MAXDISPARGS  1024	/* max arguments passed to dispatcher*/

#endif /* _MAXDISPARGS_H */
