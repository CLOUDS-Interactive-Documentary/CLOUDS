/* cmixfuns.h */

double rand1(double *);
double randi(double []);
void toneset(float, double, int, double *);

