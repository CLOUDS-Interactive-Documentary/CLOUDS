/* RTcmix - Copyright (C) 2004  The RTcmix Development Team
   See ``AUTHORS'' for a list of contributors. See ``LICENSE'' for
   the license to this software and for a DISCLAIMER OF ALL WARRANTIES.
*/
#ifndef _OUGENS_H_
#define _OUGENS_H_ 1

#include "../genlib/Oallpass.h"
#include "../genlib/Oallpassi.h"
#include "../genlib/Obalance.h"
#include "../genlib/Obucket.h"
#include "../genlib/Ocomb.h"
#include "../genlib/Ocombi.h"
#include "../genlib/Odcblock.h"
#include "../genlib/Odelay.h"
#include "../genlib/Odelayi.h"
#include "../genlib/Odistort.h"
#include "../genlib/Oequalizer.h"
#include "../genlib/Offt.h"
#include "../genlib/Oonepole.h"
#include "../genlib/Ooscil.h"
#include "../genlib/Ooscili.h"
#include "../genlib/Orand.h"
#include "../genlib/Oreson.h"
#include "../genlib/Orms.h"
#include "../genlib/Ortgetin.h"
#include "../genlib/Ostrum.h"

#endif // _OUGENS_H_
